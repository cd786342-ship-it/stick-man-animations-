# 🎬 StickMotion — Hướng Dẫn Cài Đặt

## Yêu cầu
- Node.js 18+ (tải tại https://nodejs.org)
- Tài khoản Google (miễn phí)
- Tài khoản Facebook Developer (miễn phí)

---

## BƯỚC 1 — Tạo Firebase Project

1. Truy cập https://console.firebase.google.com
2. Nhấn **"Add project"** → Đặt tên (ví dụ: `stickmotion`)
3. Tắt Google Analytics (không cần) → **Create project**

---

## BƯỚC 2 — Bật Authentication

1. Trong Firebase Console → chọn **Authentication** (menu trái)
2. Nhấn **"Get started"**
3. Bật các providers:

### Google:
- Nhấn **Google** → Toggle **Enable**
- Điền **Project support email** (email của bạn)
- **Save**

### Facebook:
- Nhấn **Facebook** → Toggle **Enable**
- Cần **App ID** và **App Secret** từ Facebook (xem Bước 3)
- **Save**

### Email/Password:
- Nhấn **Email/Password** → Toggle **Enable** → **Save**

---

## BƯỚC 3 — Tạo Facebook App

> ⚠️ Chỉ cần nếu muốn đăng nhập Facebook

1. Truy cập https://developers.facebook.com
2. **My Apps** → **Create App**
3. Chọn **"Consumer"** → Đặt tên app → **Create**
4. Vào **Settings > Basic** → copy **App ID** và **App Secret**
5. Paste vào Firebase Authentication → Facebook provider
6. Copy **OAuth redirect URI** từ Firebase → paste vào Facebook:
   - Facebook App → **Facebook Login** → **Settings**
   - Điền URI vào **Valid OAuth Redirect URIs**

---

## BƯỚC 4 — Lấy Firebase Config

### Web Config (cho frontend):
1. Firebase Console → **Project Settings** (bánh răng) → **Your apps**
2. Nhấn icon **</> Web** → Đặt tên app → **Register**
3. Copy đoạn `firebaseConfig` — gồm: apiKey, authDomain, projectId...

### Service Account (cho backend):
1. **Project Settings** → **Service accounts**
2. Nhấn **"Generate new private key"** → **Generate key**
3. File JSON được tải xuống — giữ bí mật!

---

## BƯỚC 5 — Bật Firestore Database

1. Firebase Console → **Firestore Database** → **Create database**
2. Chọn **Start in production mode** → Chọn vùng (asia-southeast1) → **Enable**
3. Vào **Rules** → paste rule sau:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /animations/{doc} {
      allow read, write: if request.auth != null && request.auth.uid == resource.data.uid;
      allow create: if request.auth != null;
    }
  }
}
```

4. **Publish**

---

## BƯỚC 6 — Cấu hình .env

```bash
# Trong thư mục stickmotion:
cp .env.example .env
```

Mở file `.env` và điền:

```env
# Từ file JSON Service Account đã tải:
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-xxxxx@your-project.iam.gserviceaccount.com
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"

# Từ Firebase Web Config:
NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSy...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abc123

SESSION_SECRET=random-string-here-change-this
```

---

## BƯỚC 7 — Điền Config vào Frontend

Mở file `public/index.html`, tìm đoạn:

```js
const firebaseConfig = {
  apiKey:            "PASTE_YOUR_apiKey_HERE",
  authDomain:        "PASTE_YOUR_authDomain_HERE",
  ...
};
```

Thay bằng giá trị thật từ Firebase Web Config.

---

## BƯỚC 8 — Cài đặt & Chạy

```bash
# Vào thư mục project
cd stickmotion

# Cài dependencies
npm install

# Chạy development
npm run dev

# Hoặc chạy production
npm start
```

Truy cập: **http://localhost:3000** 🎉

---

## BƯỚC 9 — Deploy lên Internet (tùy chọn)

### Dùng Railway (miễn phí, dễ nhất):
1. Tạo tài khoản tại https://railway.app
2. **New Project** → **Deploy from GitHub repo**
3. Thêm các biến môi trường từ `.env` vào Railway
4. Railway sẽ tự động deploy và cấp domain miễn phí

### Dùng Render:
1. https://render.com → **New Web Service**
2. Connect GitHub → Chọn repo
3. Build command: `npm install`
4. Start command: `node server.js`
5. Thêm Environment Variables

---

## Cấu trúc thư mục

```
stickmotion/
├── server.js          ← Node.js + Express server
├── package.json
├── .env               ← Biến môi trường (KHÔNG commit lên git!)
├── .env.example       ← Template
├── .gitignore
├── HUONG_DAN.md       ← File này
└── public/
    └── index.html     ← Toàn bộ frontend
```

---

## Lưu ý bảo mật

- ❌ **Không** commit file `.env` lên GitHub
- ❌ **Không** chia sẻ Service Account JSON
- ✅ Thêm `.env` vào `.gitignore`
- ✅ Firebase API Key trong frontend là an toàn (bị giới hạn bởi domain)
