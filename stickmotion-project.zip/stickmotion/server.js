// ═══════════════════════════════════════════════════
//  STICKMOTION SERVER  —  Node.js + Firebase Admin
// ═══════════════════════════════════════════════════
require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const path = require('path');
const admin = require('firebase-admin');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Firebase Admin Init ───────────────────────────
admin.initializeApp({
  credential: admin.credential.cert({
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
  }),
});

const db = admin.firestore();

// ─── Middleware ────────────────────────────────────
app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// ─── Auth Middleware ───────────────────────────────
async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Chưa đăng nhập' });
  }
  const idToken = authHeader.split('Bearer ')[1];
  try {
    const decoded = await admin.auth().verifyIdToken(idToken);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token không hợp lệ' });
  }
}

// ─── API: Get user profile ─────────────────────────
app.get('/api/me', requireAuth, async (req, res) => {
  const { uid, email, name, picture } = req.user;
  res.json({ uid, email, name, picture });
});

// ─── API: Get animations ───────────────────────────
app.get('/api/animations', requireAuth, async (req, res) => {
  try {
    const snap = await db
      .collection('animations')
      .where('uid', '==', req.user.uid)
      .orderBy('savedAt', 'desc')
      .get();
    const anims = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json(anims);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Lỗi server' });
  }
});

// ─── API: Save animation ───────────────────────────
app.post('/api/animations', requireAuth, async (req, res) => {
  const { name, frames, fps } = req.body;
  if (!name || !frames || !fps) {
    return res.status(400).json({ error: 'Thiếu dữ liệu' });
  }
  try {
    // Check if animation with same name exists for this user
    const existing = await db
      .collection('animations')
      .where('uid', '==', req.user.uid)
      .where('name', '==', name)
      .get();

    const data = {
      uid: req.user.uid,
      name,
      frames,
      fps,
      savedAt: admin.firestore.FieldValue.serverTimestamp(),
    };

    let docId;
    if (!existing.empty) {
      docId = existing.docs[0].id;
      await db.collection('animations').doc(docId).update(data);
    } else {
      const ref = await db.collection('animations').add(data);
      docId = ref.id;
    }
    res.json({ id: docId, ...data });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Lỗi lưu dữ liệu' });
  }
});

// ─── API: Delete animation ─────────────────────────
app.delete('/api/animations/:id', requireAuth, async (req, res) => {
  try {
    const doc = await db.collection('animations').doc(req.params.id).get();
    if (!doc.exists || doc.data().uid !== req.user.uid) {
      return res.status(403).json({ error: 'Không có quyền' });
    }
    await db.collection('animations').doc(req.params.id).delete();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Lỗi xóa dữ liệu' });
  }
});

// ─── Serve frontend ────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ─── Start ─────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🎬 StickMotion server chạy tại: http://localhost:${PORT}\n`);
});
